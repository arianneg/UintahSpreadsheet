﻿Tyler Centini 
Arianne Grimes

Author: Tyler Centini
Date: 10/7/2016
The spreadsheet I plan on using both my formula class and my dependency graph
it will be backed by the dependency graph and formula will be passed as a parameter for setting 
the cells with said formulas. It will also be backed by a dictionary that will hold the cells, the keys
will be the names of the said cells.

Author: Arianne Grimes
Date: 11/3/2016
The GUI's additional feature is that arrow keys can be used to move around to different cells in the spreadsheet. 
When an arrow key is used to move to a new cell, that cell's contents and value are displayed in the boxes 
above the grid. Also, the old cell's value is set into the grid.
If a formula is entered that relies on another cell, but that cell does not have a numerical value, an error message 
is displyed in the formula cell. However, all formula cells are updated when the cells that they depend on are updated. 
